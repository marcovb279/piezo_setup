The "stdcall" directory contains the siosifm.dll compiled _stdcall as calling convention.

It allows to use the siosifm.dll in VisualBasic6.

